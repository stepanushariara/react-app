import QuoteItem from 'Components/QuoteItem/QuoteItem';
import SortingQuotes from 'Components/SortingQuotes/SortingQuotes';
import { INIT_SORT } from 'Constants/ConsQuotes';
import { ModelQuoteItem } from 'Models/ModelQuote';
import { useCallback, useMemo } from 'react';
import { useSearchParams } from 'react-router-dom';
import SortQuotes from 'Utils/SortQuotes';
import StylesQuoteList from './QuoteList.module.css';

const QuoteList: React.FC<{ quotes: ModelQuoteItem[] }> = (props) => {
  const { quotes } = props;
  const [searchParams, setSearchParams] = useSearchParams();
  const getSorting = searchParams.get('sort') === INIT_SORT.asc;
  const sortedQuotes = useMemo(() => SortQuotes(quotes, getSorting), [getSorting, quotes]);

  const sortHandler = useCallback(() => {
    setSearchParams({ sort: getSorting ? INIT_SORT.desc : INIT_SORT.asc });
  }, [getSorting, setSearchParams]);

  return (
    <>
      <SortingQuotes onSortHandler={sortHandler} sort={getSorting} />
      <ul className={StylesQuoteList.list}>
        {sortedQuotes.map((val, key: number) => (
          <QuoteItem key={val.id} id={val.id} author={val.author} text={val.text} />
        ))}
      </ul>
    </>
  );
};

export default QuoteList;
