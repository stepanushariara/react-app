import { useState } from 'react';

const Comments: React.FC = () => {
  const [isAddComment, setIsAddComment] = useState(false);

  const addComment = () => {
    return <>{!isAddComment && <p>this button</p>}</>;
  };

  const showCommentBox = () => {
    return <>{isAddComment && <p>Show comment box</p>}</>;
  };

  return (
    <section>
      <h2>Comments</h2>
      {addComment}
      {showCommentBox}
    </section>
  );
};
export default Comments;
