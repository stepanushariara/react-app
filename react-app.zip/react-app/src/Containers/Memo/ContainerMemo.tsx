import Output from 'Components/MemoOutput/Output';
import { useCallback, useMemo, useState } from 'react';

const ContainerMemo: React.FC = () => {
  const [state, setState] = useState('');

  const stateHandler = useCallback(() => {
    setState('Text was set!');
  }, []);

  const list = useMemo(() => [3, 5, 7, 8, 2], []);

  return (
    <div>
      <Output text={state} arr={list} />
      <button onClick={stateHandler}>Set The Text</button>
    </div>
  );
};
export default ContainerMemo;
