import UseReducerInput from 'Hooks/UseReducerInput';
import Spinner from 'UI/Spinner/Spinner';
import StylesQuoteForm from './QuoteForm.module.css';

//will be moved to Models
type props = {
  onSubmitHandler: Function;
};

const QuoteForm: React.FC<props> = (props) => {
  let isDisabled = false;
  let isLoading = false;
  const validatorText = (val: string) => val.trim() !== '';
  const validatorEmail = (val: string) => val.includes('@');

  const {
    value: valueAuthor,
    isValid: isValidAuthor,
    isError: isErrorAuthor,
    onChangeInput: onChangeAuthor,
    onBlurInput: onBlurAuthor,
    onResetInput: onResetAuthor,
  } = UseReducerInput(validatorText);

  const {
    value: valueEmail,
    isValid: isValidEmail,
    isError: isErrorEmail,
    onChangeInput: onChangeEmail,
    onBlurInput: onBlurEmail,
    onResetInput: onResetEmail,
  } = UseReducerInput(validatorEmail);

  const {
    value: valueDesc,
    isValid: isValidDesc,
    isError: isErrorDesc,
    onChangeInput: onChangeDesc,
    onBlurInput: onBlurDesc,
    onResetInput: onResetDesc,
  } = UseReducerInput(validatorText);

  if (isValidAuthor && isValidEmail && isValidDesc) {
    isDisabled = false;
  } else {
    isDisabled = true;
  }

  const onSubmitQuote = (e: any) => {
    e.preventDefault();
    console.log('executed');

    onResetAuthor();
    onResetEmail();
    onResetDesc();
  };

  return (
    <form className={StylesQuoteForm.form} onSubmit={onSubmitQuote}>
      {isLoading && (
        <div className={StylesQuoteForm.loading}>
          <Spinner />
        </div>
      )}

      <div className={StylesQuoteForm.control}>
        <label htmlFor="author">Author</label>
        <input type="text" id="author" value={valueAuthor} onChange={onChangeAuthor} onBlur={onBlurAuthor} />
        {isErrorAuthor && <p className={StylesQuoteForm.error}>Please enter the Author.</p>}
      </div>

      <div className={StylesQuoteForm.control}>
        <label htmlFor="author">Email</label>
        <input type="text" id="author" value={valueEmail} onChange={onChangeEmail} onBlur={onBlurEmail} />
        {isErrorEmail && <p className={StylesQuoteForm.error}>Please enter valid email.</p>}
      </div>

      <div className={StylesQuoteForm.control}>
        <label htmlFor="description">Author</label>
        <textarea rows={5} id="description" value={valueDesc} onChange={onChangeDesc} onBlur={onBlurDesc} />
        {isErrorDesc && <p className={StylesQuoteForm.error}>Please enter the Quote.</p>}
      </div>

      <div className={StylesQuoteForm.actions}>
        <button disabled={isDisabled} className="btn">
          Add Quote
        </button>
      </div>
    </form>
  );
};
export default QuoteForm;
