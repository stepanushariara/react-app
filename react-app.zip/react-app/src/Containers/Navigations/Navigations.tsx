import { NavLink } from 'react-router-dom';
import StylesNav from './Navigations.module.css';

const Navigations = () => {
  return (
    <>
      <header className={StylesNav.header}>
        <div className={StylesNav.logo}>Great Quotes</div>
        <nav className={StylesNav.nav}>
          <ul>
            <li>
              <NavLink to={'/quotes'} className={(navData) => (navData.isActive ? StylesNav.active : '')}>
                All Quotes
              </NavLink>
            </li>

            <li>
              <NavLink to={'/new'} className={(navData) => (navData.isActive ? StylesNav.active : '')}>
                Add a Quote
              </NavLink>
            </li>
          </ul>
        </nav>
      </header>
    </>
  );
};
export default Navigations;
