import Navigations from 'Containers/Navigations/Navigations';
import StylesLayout from './Layout.module.css';

const Layout: React.FC<{ children: any }> = (props) => {
  const { children } = props;
  return (
    <>
      <Navigations />
      <main className={StylesLayout.main}>{children}</main>
    </>
  );
};
export default Layout;
