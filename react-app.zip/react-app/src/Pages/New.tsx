import { useNavigate } from 'react-router-dom';
import QuoteForm from 'Containers/QuoteForm/QuoteForm';

const New: React.FC = () => {
  const navigate = useNavigate();
  const addQuoteHandler = () => {
    navigate('/quotes');
  };
  return <QuoteForm onSubmitHandler={addQuoteHandler} />;
};
export default New;
