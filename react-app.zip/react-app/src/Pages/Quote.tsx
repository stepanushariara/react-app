import { Link, Outlet, useParams } from 'react-router-dom';
import { INIT_QUOTES } from 'Constants/ConsQuotes';
import HighlightedQuote from 'Components/HighlightedQuote/HighlightedQuote';

const Quote: React.FC = () => {
  const params = useParams();

  const quote = INIT_QUOTES.find((quote) => quote.id === params.id);

  if (!quote) {
    return <p>QUote not found!</p>;
  }

  const loadComments = () => {
    return (
      <Link className="btn--flat" to={`comments`}>
        Load Comments
      </Link>
    );
  };

  return (
    <>
      <h1>Detail Quote</h1>
      <HighlightedQuote author={quote?.author} text={quote?.text} />
      <div className="centered">{loadComments}</div>
      <Outlet />
    </>
  );
};
export default Quote;
