import ContainerMemo from 'Containers/Memo/ContainerMemo';

const Memo: React.FC = () => {
  return (
    <div>
      <ContainerMemo />
    </div>
  );
};

export default Memo;
