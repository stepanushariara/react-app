import QuoteList from 'Containers/QuoteList/QuoteList';
import { INIT_QUOTES } from '../Constants/ConsQuotes';

const Quotes: React.FC = () => {
  return <QuoteList quotes={INIT_QUOTES} />;
};
export default Quotes;
