import React from 'react';
import './App.css';
import { Navigate, Route, Routes } from 'react-router-dom';
import Quotes from 'Pages/Quotes';
import Quote from 'Pages/Quote';
import New from 'Pages/New';
import Layout from 'Containers/Layout/Layout';
import Memo from 'Pages/Memo';
import NotFound from 'Pages/NotFound';
import Comments from 'Containers/Comments/Comments';

const App: React.FC = () => {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Navigate replace to={'/quotes'} />} />
        <Route path="/quotes" element={<Quotes />} />
        <Route path="/quote/:id/*" element={<Quote />}>
          <Route path={`comments`} element={<Comments />} />
        </Route>
        <Route path="/new" element={<New />} />
        <Route path="/memo" element={<Memo />} />
        <Route path="*" element={<Navigate replace to={'/not-found'} />} />
        <Route path="/not-found" element={<NotFound />} />
      </Routes>
    </Layout>
  );
};

export default App;
