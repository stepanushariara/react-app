import StylesHighlightedQuote from './HighlightedQuote.module.css';
import { ModelHighlightedQuote } from 'Models/ModelQuote';

const HighlightedQuote: React.FC<ModelHighlightedQuote> = (props) => {
  const { text, author } = props;

  return (
    <figure className={StylesHighlightedQuote.quote}>
      <p>{text}</p>
      <figcaption>{author}</figcaption>
    </figure>
  );
};

export default HighlightedQuote;
