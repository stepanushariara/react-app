import { ModelQuoteItem } from 'Models/ModelQuote';
import { Link } from 'react-router-dom';
import StylesQuoteItem from './QuoteItem.module.css';

const QuoteItem: React.FC<ModelQuoteItem> = (props) => {
  const { id, author, text } = props;
  return (
    <li className={StylesQuoteItem.item}>
      <figure>
        <blockquote>
          <p>{text}</p>
        </blockquote>
        <figcaption>{author}</figcaption>
      </figure>
      <Link className="btn" to={`/quote/${id}`}>
        View Fullscreen
      </Link>
    </li>
  );
};

export default QuoteItem;
