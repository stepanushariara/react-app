import StylesSortingQuote from './SortingQuotes.module.css';

const SortingQuotes: React.FC<{ onSortHandler: any; sort: boolean }> = (props) => {
  const { onSortHandler, sort } = props;

  return (
    <div className={StylesSortingQuote.sorting}>
      <button onClick={onSortHandler}>Sort {sort ? 'Descending' : 'Ascending'}</button>
    </div>
  );
};

export default SortingQuotes;
