import { useMemo } from 'react';

type props = {
  text: string;
  arr: number[];
};

const Output: React.FC<props> = (props) => {
  const { text, arr } = props;

  const sort = useMemo(() => {
    return arr.sort((a, b) => a - b);
  }, [arr]);

  const listArr = sort.map((val, key) => {
    return <li key={key}>{val}</li>;
  });

  return (
    <div>
      <h2>Output will be: {text}</h2>
      <ul>{listArr}</ul>
    </div>
  );
};

export default Output;
