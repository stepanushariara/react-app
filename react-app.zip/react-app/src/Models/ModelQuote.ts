export interface ModelQuoteItem {
  id: string;
  author: string;
  text: string;
}

export interface ModelHighlightedQuote {
  text?: string;
  author?: string;
}
