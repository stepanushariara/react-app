export const DIS_INPUT = 'INPUT';
export const DIS_BLUR = 'BLUR';
export const DIS_RESET = 'RESET';
