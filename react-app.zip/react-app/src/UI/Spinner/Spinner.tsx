import StylesSpinner from './Spinner.module.css';

const Spinner: React.FC = () => {
  return <div className={StylesSpinner.spinner} />;
};
export default Spinner;
