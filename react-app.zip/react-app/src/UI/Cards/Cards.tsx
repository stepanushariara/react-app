import StylesCards from './Cards.module.css';

const Cards: React.FC = (props) => {
  const { children } = props;
  return <div className={StylesCards.card}>{children}</div>;
};

export default Cards;
