import { ModelQuoteItem } from 'Models/ModelQuote';

const SortQuotes = (quotes: ModelQuoteItem[], ascending: boolean) => {
  return quotes.sort((quoteA, quoteB) => {
    if (ascending) {
      return quoteA.id > quoteB.id ? 1 : -1;
    } else {
      return quoteA.id < quoteB.id ? 1 : -1;
    }
  });
};
export default SortQuotes;
