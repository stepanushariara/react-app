import { useReducer } from 'react';
import { DIS_INPUT, DIS_BLUR, DIS_RESET } from 'Constants/ConsDispatcher';

const init = {
  value: '',
  onFocused: false,
};

const reducer = (state: any, action: any) => {
  if (action.type === DIS_INPUT) {
    return { onFocused: state.onFocused, value: action.value };
  }
  if (action.type === DIS_BLUR) {
    return { onFocused: true, value: state.value };
  }
  if (action.type === DIS_RESET) {
    return { onFocused: false, value: '' };
  } else {
    throw new Error();
  }
};

const UseReducerInput = (validateInput: Function) => {
  const [state, dispacth] = useReducer(reducer, init);

  const valueIsValid = validateInput(state.value);
  const isError = !valueIsValid && state.onFocused;

  const onChangeInput = (e: any) => {
    dispacth({ type: DIS_INPUT, value: e.target.value });
  };

  const onBlurInput = (e: any) => {
    dispacth({ type: DIS_BLUR });
  };

  const onResetInput = () => {
    dispacth({ type: DIS_RESET });
  };

  return {
    value: state.value,
    isValid: valueIsValid,
    isError,
    onChangeInput,
    onBlurInput,
    onResetInput,
  };
};
export default UseReducerInput;
